function toggleNavMenu() {
	document.getElementsById("nav")[0].classList.toggle("ul");
}